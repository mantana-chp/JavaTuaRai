package int101.basic;

import int101.basic.Simple;

public class Test {
    public static void main(String[] args) {
        testSimple();
    }
    
    static void testSimple(){
        //Simple()
        Simple s = new Simple("SimpleTitle", -20);
        
        //Simple:addAmount()
        System.out.println("Add -3.4: " + s.addAmount(-3.4));
        System.out.println("Add -5.3: " + s.addAmount(-5.3)); //false bc less than -3.4
        System.out.println("Add -1.5: " + s.addAmount(-1.5));
        System.out.println("Add 12.0: " + s.addAmount(12.0));

        //Simple:toString()
        System.out.println(s);
    }
}
