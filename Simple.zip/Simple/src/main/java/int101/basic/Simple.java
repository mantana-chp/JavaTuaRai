package int101.basic;

public class Simple {

    private String title;
    private int value;
    private double[] amounts = new double[5];
    private int count;

    public Simple(String title, int value) {
        /*this.title = title;
        this.value = value;
        
        if(this.title==null){
            this.title="NOTITLE";
        }
        if(this.value<0){
            this.value=0;
        }*/

        this.title = title == null ? "NOTITLE" : title;
        this.value = value < 0 ? 0 : value;

    }

    public boolean addAmount(double amount) {
        /*if (amount == amounts.length) {
            return false;
        }
        for (int i = 0; i < count; i++) {
            if(amount>amounts[i]){
                amounts[count++]=amount;
                return true;
            }
        }
        return false;*/
        if (count > 0 && amount <= amounts[count - 1]) {
            return false; 
        } 
        amounts[count++] = amount;
        return true;
    }

    /*
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Simple[").append("title:").append(title);
        sb.append(",value:").append(value);
        for (int i = 0; i < count; i++) {
            sb.append(" ").append(amounts[i]);
        }
        
        return sb.append("]").toString();
    }*/

    
    
    

}
